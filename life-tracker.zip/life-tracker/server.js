const express = require('express');
const path = require('path');
const pool = require('./db');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', async (req, res) => {
  try {
    const filterCat = req.query.category || 'ALL';
    const [categories] = await pool.query('SELECT * FROM categories ORDER BY id ASC');

    const [summaryRows] = await pool.query(`
      SELECT
        c.id,
        c.name,
        c.unit,
        c.target_value,
        COUNT(r.id) AS total_count,
        COALESCE(SUM(r.amount_value), 0) AS total_amount
      FROM categories c
      LEFT JOIN records r ON c.id = r.category_id
      GROUP BY c.id, c.name, c.unit, c.target_value
      ORDER BY c.id ASC
    `);

    let sql = `
      SELECT
        r.id,
        r.category_id,
        c.name AS category_name,
        c.unit,
        DATE_FORMAT(r.record_date, '%Y-%m-%d') AS record_date,
        r.title,
        r.amount_value,
        r.achieved
      FROM records r
      JOIN categories c ON r.category_id = c.id
    `;
    const params = [];

    if (filterCat !== 'ALL') {
      sql += ' WHERE c.name = ?';
      params.push(filterCat);
    }

    sql += ' ORDER BY r.record_date DESC, r.id DESC';
    const [records] = await pool.query(sql, params);

    const today = new Date().toISOString().slice(0, 10);

    res.render('index', {
      categories,
      summaryRows,
      records,
      filterCat,
      today
    });
  } catch (err) {
    console.error('조회 오류:', err);
    res.status(500).send('데이터베이스 조회 중 오류가 발생했습니다.');
  }
});

app.post('/records', async (req, res) => {
  try {
    const { category_id, record_date, title, amount_value, achieved } = req.body;
    const isAchieved = achieved === '1' || achieved === 'on' || achieved === true ? 1 : 0;

    await pool.query(
      `INSERT INTO records (category_id, record_date, title, amount_value, achieved)
       VALUES (?, ?, ?, ?, ?)`,
      [Number(category_id), record_date, title.trim(), Number(amount_value) || 0, isAchieved]
    );

    res.redirect('/');
  } catch (err) {
    console.error('추가 오류:', err);
    res.status(500).send('기록 저장 중 오류가 발생했습니다.');
  }
});

app.post('/records/:id/toggle', async (req, res) => {
  try {
    const id = Number(req.params.id);
    await pool.query(
      'UPDATE records SET achieved = IF(achieved = 1, 0, 1) WHERE id = ?',
      [id]
    );
    res.redirect('/');
  } catch (err) {
    console.error('수정 오류:', err);
    res.status(500).send('상태 변경 중 오류가 발생했습니다.');
  }
});

app.post('/records/:id/delete', async (req, res) => {
  try {
    const id = Number(req.params.id);
    await pool.query('DELETE FROM records WHERE id = ?', [id]);
    res.redirect('/');
  } catch (err) {
    console.error('삭제 오류:', err);
    res.status(500).send('삭제 중 오류가 발생했습니다.');
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Life Tracker running at http://0.0.0.0:${PORT}`);
});
